copy files in the same folders of your maya 2008 directory.

before overwrite the AELambertTemplate.mel please do a backup of the original one.

Feel free to contact me for any questions or suggestions at

filipe@asianalternative.com