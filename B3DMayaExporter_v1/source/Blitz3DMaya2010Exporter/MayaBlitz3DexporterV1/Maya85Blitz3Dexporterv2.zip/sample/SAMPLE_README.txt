This folders contains a Maya binary file, for 8.5 version.



drag and drop b3d file onto Blitz3D_animmeshViewer.exe or Blitz3D_meshViewer.exe  to see a preview.

use "q" and  "w" to zoom in/out and arrows to turn object.